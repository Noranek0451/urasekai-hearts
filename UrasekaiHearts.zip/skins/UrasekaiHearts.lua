local skin = {
	name = {
		["en-us"] = "Otherside Picnic"
	},
    suit = "H",
    texture = "UrasekaiHearts.png",
	cards = { "J", "Q", "K" }
}

return skin